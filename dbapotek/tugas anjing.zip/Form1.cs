﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace tugas_anjing
{
    public partial class Form1 : Form
    {
        MySqlConnection con = new MySqlConnection(@"Data Source = localhost;port=3306;Initial Catalog = dbApotek ;User Id = root;password ='marcell98'");

        public Form1()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void hScrollBar1_Scroll(object sender, ScrollEventArgs e)
        {
                    }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void bunifuFlatButton1_Click(object sender, EventArgs e)
        {//nip belum
            string insertQuery = "insert into transaksi values('" + textBox2.Text + "','" + textBox3.Text + "','" + te.Text + "','" + textBox5.Text + "','" + textBox7.Text + "')";
            string insertQuery = "insert into obat  values('" + textBox3.Text + "','" + textBox4.Text + "','" + comboBox1.Text + "','" + dateTimePicker1 + "','" + textBox1.Text "')";
            string insertQuery = "insert into supplier  values('" + textBox1.Text + "','" + textBox6.Text + "')";

            con.Open();
            MySqlCommand command = new MySqlCommand(insertQuery, con);
            try
            {
                if (command.ExecuteNonQuery() == 1)
                {
                    MessageBox.Show("Insert Successful!");
                   
                }
                else
                {
                    MessageBox.Show("Data is invalid \n Please Try Again!");
                  
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            
            con.Close();

        }

        private void bunifuGradientPanel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void bunifuFlatButton7_Click(object sender, EventArgs e)
        {
            login f3 = new login();
            f3.Show();
            this.Hide();
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
